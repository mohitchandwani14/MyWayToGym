package Gym.Mngmt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import Gym.Mngmt.modal.GymOwner;
import Gym.Mngmt.modal.Login;

public interface LoginRepository extends JpaRepository<Login, Integer> {
	
	public Login findByemailAndPassword(String email, String password);

	@Query("select u from Login u where u.email = :email")
	public Login getUserByUserName(@Param("email") String email);
}
