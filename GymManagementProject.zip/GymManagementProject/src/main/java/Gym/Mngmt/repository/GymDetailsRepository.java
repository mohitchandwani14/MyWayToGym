package Gym.Mngmt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import Gym.Mngmt.modal.GymDetails;



@Repository
public interface GymDetailsRepository<GymDetailsRepository> extends JpaRepository<GymDetails, Long>  {
	
	
	
	@Query("select c from GymDetails  c where c.city=:city " ) 
	public List<GymDetails> findGymDetailsByUser(@Param("city") String city);
	
	
	@Query("select c from GymDetails c where c.owner_id=:owner_id")
	public List<GymDetails> getGymdetailsByOwnerId(int owner_id);

	
}
