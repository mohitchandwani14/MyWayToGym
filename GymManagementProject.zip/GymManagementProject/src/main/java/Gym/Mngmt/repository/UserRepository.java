package Gym.Mngmt.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.modal.User;

public interface UserRepository extends CrudRepository<Customer, Integer> {

	 Customer findBycustEmail(String custEmail);	
	
	
	  //public User findByemailIdAndPassword(String emailId, String password);
//	 @Query("from Customer" )
//		public List<Customer> showCustomerByAdmin();

}

