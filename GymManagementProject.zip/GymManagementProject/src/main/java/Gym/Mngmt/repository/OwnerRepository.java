package Gym.Mngmt.repository;

import org.springframework.data.repository.CrudRepository;

import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.modal.GymOwner;

public interface OwnerRepository  extends CrudRepository<GymOwner, Integer> {

	GymOwner findByownerEmail(String email);

	
	


}
