package Gym.Mngmt.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class Customer {
	
		@Id
		@GeneratedValue(strategy=GenerationType.IDENTITY)
		private	int custId;
		@NotEmpty(message="Name must not be empty")
		@Size(min = 5,max = 30,message="Length must be in Between 5 and 30")
		@Pattern(regexp =  "^[a-zA-Z\\s]*$", message="Only characters are allowed")
		private String custName;
		@NotEmpty(message="Mobile number must not be empty")
		@Size(min=10,max=10,message="Length of mobile number must be 10 digits")
		@Pattern(regexp="^(\\+91[\\-\\s]?)?[0]?(91)?[6789]\\d{9}$" , message="Enter a valid mobile number")
		private String custMobile;
	
		@Column(unique = true)
		@NotEmpty(message="Email must not be empty")
		@Pattern(regexp = "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])",message="Email must be in specific format ex: abc123@gmail.com")
		private String custEmail;
		//@Pattern(regexp="^(?=.*[a-z])(?=.*\\d)(?=.*[@.])[A-Za-z\\d@.]{20,}$", message="Only Invalid  are allowed" )
		
		@NotEmpty
		//@Pattern(regexp="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$", message="Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character")
		private String custPassword;
		private String custGender;
		private String custAge;
		
		@NotEmpty
		private String street;
		@NotEmpty
		private String city;
		@NotEmpty
		private String state;
		@NotEmpty
		private String pincode;
//		
//		@ManyToOne(fetch = FetchType.LAZY, optional = false)
//	    @JoinColumn(name = "gym_id", nullable = false)
//		private GymDetails gymDetails;
	
		public Customer() {
			super();
			// TODO Auto-generated constructor stub
		}
		

		



		







		public Customer(
				@NotEmpty(message = "Name must not be empty") @Size(min = 5, max = 30, message = "Length must be in Between 5 and 30") @Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only characters are allowed") String custName,
				@NotEmpty(message = "Mobile number must not be empty") @Size(min = 10, max = 10, message = "Length of mobile number must be 10 digits") @Pattern(regexp = "^(\\+91[\\-\\s]?)?[0]?(91)?[6789]\\d{9}$", message = "Enter a valid mobile number") String custMobile,
				@NotEmpty(message = "Email must not be empty") @Pattern(regexp = "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])", message = "Email must be in specific format ex: abc123@gmail.com") String custEmail,
				@NotEmpty String custPassword, String custGender, String custAge, @NotEmpty String street,
				@NotEmpty String city, @NotEmpty String state, @NotEmpty String pincode) {
			super();
			this.custName = custName;
			this.custMobile = custMobile;
			this.custEmail = custEmail;
			this.custPassword = custPassword;
			this.custGender = custGender;
			this.custAge = custAge;
			this.street = street;
			this.city = city;
			this.state = state;
			this.pincode = pincode;
			
		}














		public Customer(int custId,
				@NotEmpty(message = "Name must not be empty") @Size(min = 5, max = 30, message = "Length must be in Between 5 and 30") @Pattern(regexp = "^[a-zA-Z\\s]*$", message = "Only characters are allowed") String custName,
				@NotEmpty(message = "Mobile number must not be empty") @Size(min = 10, max = 10, message = "Length of mobile number must be 10 digits") @Pattern(regexp = "^(\\+91[\\-\\s]?)?[0]?(91)?[6789]\\d{9}$", message = "Enter a valid mobile number") String custMobile,
				@NotEmpty(message = "Email must not be empty") @Pattern(regexp = "(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])", message = "Email must be in specific format ex: abc123@gmail.com") String custEmail,
				@NotEmpty String custPassword, String custGender, String custAge, @NotEmpty String street,
				@NotEmpty String city, @NotEmpty String state, @NotEmpty String pincode) {
			super();
			this.custId = custId;
			this.custName = custName;
			this.custMobile = custMobile;
			this.custEmail = custEmail;
			this.custPassword = custPassword;
			this.custGender = custGender;
			this.custAge = custAge;
			this.street = street;
			this.city = city;
			this.state = state;
			this.pincode = pincode;
			
		}











		


//		public GymDetails getGymDetails() {
//			return gymDetails;
//		}
//
//
//		public void setGymDetails(GymDetails gymDetails) {
//			this.gymDetails = gymDetails;
//		}


		public int getCustId() {
			return custId;
		}

		public void setCustId(int custId) {
			this.custId = custId;
		}

		public String getCustName() {
			return custName;
		}

		public void setCustName(String custName) {
			this.custName = custName;
		}

		public String getCustMobile() {
			return custMobile;
		}

		public void setCustMobile(String custMobile) {
			this.custMobile = custMobile;
		}

		public String getCustEmail() {
			return custEmail;
		}

		public void setCustEmail(String custEmail) {
			this.custEmail = custEmail;
		}

		public String getCustPassword() {
			return custPassword;
		}

		public void setCustPassword(String custPassword) {
			this.custPassword = custPassword;
		}

		public String getCustGender() {
			return custGender;
		}

		public void setCustGender(String custGender) {
			this.custGender = custGender;
		}

		public String getCustAge() {
			return custAge;
		}

		public void setCustAge(String custAge) {
			this.custAge = custAge;
		}



		public String getStreet() {
			return street;
		}



		public void setStreet(String street) {
			this.street = street;
		}



		public String getCity() {
			return city;
		}



		public void setCity(String city) {
			this.city = city;
		}



		public String getState() {
			return state;
		}



		public void setState(String state) {
			this.state = state;
		}



		public String getPincode() {
			return pincode;
		}



		public void setPincode(String pincode) {
			this.pincode = pincode;
		}



		@Override
		public String toString() {
			return "Customer [custId=" + custId + ", custName=" + custName + ", custMobile=" + custMobile
					+ ", custEmail=" + custEmail + ", custPassword=" + custPassword + ", custGender=" + custGender
					+ ", custAge=" + custAge + ", street=" + street + ", city=" + city + ", state=" + state
					+ ", pincode=" + pincode + "]";
		}

		
		
	

}
