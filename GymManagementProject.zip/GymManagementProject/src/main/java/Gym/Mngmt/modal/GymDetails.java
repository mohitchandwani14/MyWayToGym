package Gym.Mngmt.modal;



import java.beans.Transient;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name = "GymDetails")
public class GymDetails {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column
	private long gymId;
	@Column(nullable = false, length = 45)
	@NotEmpty
	private String gymName;
	@Column(nullable = false, length = 1000)
	private String gymDescription;
	@Column
	private String noofTrainer;
	@Column
	private String features;
//	@Column
//	private String plan;
//	@Column
//	private int discount;
	@Column
	private String gymPhoto;
	
	private String street;
	private String state;
	private String city;
	private String pincode;
	
	private int owner_id;

	
//	   @OneToMany(cascade = CascadeType.ALL,fetch=FetchType.LAZY,mappedBy ="customer") 
//	private List<Customer> customer=new ArrayList<Customer>(); //
	 	public GymDetails() {
		super();
		
	}

	

	@Override
	public String toString() {
		return "GymDetails [gymId=" + gymId + ", gymName=" + gymName + ", gymDescription=" + gymDescription
				+ ", noofTrainer=" + noofTrainer + ", features=" + features + ", gymPhoto=" + gymPhoto + ", street=" + street + ", state=" + state + ", city=" + city
				+ ", pincode=" + pincode + "]";
	}

	

	public GymDetails(long gymId, String gymName, String gymDescription, String noofTrainer, String features,
			int owner_id) {
		super();
		this.gymId = gymId;
		this.gymName = gymName;
		this.gymDescription = gymDescription;
		this.noofTrainer = noofTrainer;
		this.features = features;
		this.owner_id = owner_id;
	}
	


//	public List<Customer> getCustomer() {
//		return customer;
//	}
//
//
//
//	public void setCustomer(List<Customer> customer) {
//		this.customer = customer;
//	}



	public long getGymId() {
		return gymId;
	}

	public void setGymId(long gymId) {
		this.gymId = gymId;
	}

	public String getGymName() {
		return gymName;
	}

	public void setGymName(String gymName) {
		this.gymName = gymName;
	}

	public String getGymDescription() {
		return gymDescription;
	}

	public void setGymDescription(String gymDescription) {
		this.gymDescription = gymDescription;
	}

	public String getNoofTrainer() {
		return noofTrainer;
	}

	public void setNoofTrainer(String noofTrainer) {
		this.noofTrainer = noofTrainer;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

//	public String getPlan() {
//		return plan;
//	}
//
//	public void setPlan(String plan) {
//		this.plan = plan;
//	}
//
//	public int getDiscount() {
//		return discount;
//	}
//
//	public void setDiscount(int discount) {
//		this.discount = discount;
//	}

	public String getGymPhoto() {
		return gymPhoto;
	}

	public void setGymPhoto(String gymPhoto) {
		this.gymPhoto = gymPhoto;
	}
	@Transient
    public String getPhotosImagePath() {
        if (gymPhoto == null || gymId == 0) return null;
         
        return "/gymDetails-photos/" + gymId + "/" + gymPhoto;
    }
	public GymDetails(String gymName, String gymDescription, String noofTrainer, String features, 
			 String gymPhoto, String street, String state, String city, String pincode) {
		super();
		this.gymName = gymName;
		this.gymDescription = gymDescription;
		this.noofTrainer = noofTrainer;
		this.features = features;
		
		this.gymPhoto = gymPhoto;
		this.street = street;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}



	public GymDetails(String gymName, String gymDescription, String noofTrainer, String features, 
			 String gymPhoto, String street, String state, String city, String pincode, int owner_id) {
		super();
		this.gymName = gymName;
		this.gymDescription = gymDescription;
		this.noofTrainer = noofTrainer;
		this.features = features;
//		this.plan = plan;
//		this.discount = discount;
		this.gymPhoto = gymPhoto;
		this.street = street;
		this.state = state;
		this.city = city;
		this.pincode = pincode;
		this.owner_id = owner_id;
	}



	public int getOwner_id() {
		return owner_id;
	}



	public void setOwner_id(int owner_id) {
		this.owner_id = owner_id;
	}



	

	

	
	

}
