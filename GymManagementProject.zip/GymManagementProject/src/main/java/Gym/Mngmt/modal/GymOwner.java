package Gym.Mngmt.modal;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;

@Entity
public class GymOwner {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private	int ownerId;
	private String ownerName;
	private String ownerMobile;
	private String ownerEmail;
	private String ownerPassword;
	private String ownerGender;
	private String ownerAge;
	
	@NotEmpty
	private String street;
	@NotEmpty
	private String city;
	@NotEmpty
	private String state;
	@NotEmpty
	private String pincode;
	
//	@OneToMany(cascade = CascadeType.ALL,fetch=FetchType.LAZY,mappedBy = "gymOwner")
//	private List<GymDetails> gymDetails=new ArrayList<GymDetails>();

	public GymOwner() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public GymOwner(String ownerName, String ownerMobile, String ownerEmail, String ownerPassword, String ownerGender,
		String ownerAge, @NotEmpty String street, @NotEmpty String city, @NotEmpty String state,
		@NotEmpty String pincode) {
	super();
	this.ownerName = ownerName;
	this.ownerMobile = ownerMobile;
	this.ownerEmail = ownerEmail;
	this.ownerPassword = ownerPassword;
	this.ownerGender = ownerGender;
	this.ownerAge = ownerAge;
	this.street = street;
	this.city = city;
	this.state = state;
	this.pincode = pincode;
}



	public GymOwner(int ownerId, String ownerName, String ownerMobile, String ownerEmail, String ownerPassword,
		String ownerGender, String ownerAge, @NotEmpty String street, @NotEmpty String city, @NotEmpty String state,
		@NotEmpty String pincode) {
	super();
	this.ownerId = ownerId;
	this.ownerName = ownerName;
	this.ownerMobile = ownerMobile;
	this.ownerEmail = ownerEmail;
	this.ownerPassword = ownerPassword;
	this.ownerGender = ownerGender;
	this.ownerAge = ownerAge;
	this.street = street;
	this.city = city;
	this.state = state;
	this.pincode = pincode;
}



	public int getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(int ownerId) {
		this.ownerId = ownerId;
	}

	public String getOwnerName() {
		return ownerName;
	}

	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}

	public String getOwnerMobile() {
		return ownerMobile;
	}

	public void setOwnerMobile(String ownerMobile) {
		this.ownerMobile = ownerMobile;
	}

	public String getOwnerEmail() {
		return ownerEmail;
	}

	public void setOwnerEmail(String ownerEmail) {
		this.ownerEmail = ownerEmail;
	}

	public String getOwnerPassword() {
		return ownerPassword;
	}

	public void setOwnerPassword(String ownerPassword) {
		this.ownerPassword = ownerPassword;
	}

	public String getOwnerGender() {
		return ownerGender;
	}

	public void setOwnerGender(String ownerGender) {
		this.ownerGender = ownerGender;
	}

	public String getOwnerAge() {
		return ownerAge;
	}

	public void setOwnerAge(String ownerAge) {
		this.ownerAge = ownerAge;
	}



	public String getStreet() {
		return street;
	}



	public void setStreet(String street) {
		this.street = street;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getPincode() {
		return pincode;
	}



	public void setPincode(String pincode) {
		this.pincode = pincode;
	}



	@Override
	public String toString() {
		return "GymOwner [ownerId=" + ownerId + ", ownerName=" + ownerName + ", ownerMobile=" + ownerMobile
				+ ", ownerEmail=" + ownerEmail + ", ownerPassword=" + ownerPassword + ", ownerGender=" + ownerGender
				+ ", ownerAge=" + ownerAge + ", street=" + street + ", city=" + city + ", state=" + state + ", pincode="
				+ pincode + "]";
	}
	
	/*
	 * public Address getAddress() { return address; }
	 * 
	 * public void setAddress(Address address) { this.address = address; }
	 */
	
//	public List<GymDetails> getGymDetails() {
//		return gymDetails;
//	}
//
//	public void setGymDetails(List<GymDetails> gymDetails) {
//		this.gymDetails = gymDetails;
//	}

	/*
	 * @Override public String toString() { return "GymOwner [ownerId=" + ownerId +
	 * ", ownerName=" + ownerName + ", ownerMobile=" + ownerMobile + ", ownerEmail="
	 * + ownerEmail + ", ownerPassword=" + ownerPassword + ", ownerGender=" +
	 * ownerGender + ", ownerAge=" + ownerAge + ", address=" + address + "]"; }
	 */
	
	
}
