package Gym.Mngmt.services;

import java.util.List;

import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.modal.GymDetails;
import Gym.Mngmt.modal.GymOwner;






public interface GymDetailsService {
	public GymDetails addGymDetails(GymDetails gymDetails);
	List<GymDetails> getGymdetails();
	void saveGymdetails(GymDetails gymdetails);
	GymDetails getGymdetailsById(long id);
	void deleteGymdetailsById(Integer id);
	public List<GymDetails> getGymDataById(long gymId);
//	public void updateGymDetails();
	public List<GymOwner> getGymOwners();
	public List<Customer> getCustomers();
}
