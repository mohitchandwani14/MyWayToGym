package Gym.Mngmt.services;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.modal.GymOwner;
import Gym.Mngmt.modal.Login;
import Gym.Mngmt.modal.User;
import Gym.Mngmt.repository.LoginRepository;
import Gym.Mngmt.repository.OwnerRepository;
import Gym.Mngmt.repository.UserRepository;

@Service
@Transactional
public class UserService {

	private final UserRepository userRepository;
	private final OwnerRepository ownerRepository;
	private final LoginRepository loginRepository;

	public UserService(UserRepository userRepository,OwnerRepository ownerRepository,LoginRepository loginRepository) {
		this.userRepository = userRepository;
		this.ownerRepository = ownerRepository;
		this.loginRepository = loginRepository;
	}
	

	

	public void saveMyUser(Customer cust) {
		userRepository.save(cust);
	}
	public void saveMyUser(GymOwner gym) {
		ownerRepository.save(gym);
	}




	public void saveMyUser(Login login) {
		loginRepository.save(login);
		
	}

//	public User findByUsernameAndPassword(String username, String password) {
//		return userRepository.findByUsernameAndPassword(username, password);
//	}

	
	  public Login findByemailAndPassword(String email, String password) {
	  return loginRepository.findByemailAndPassword(email, password); 
	  }




	public Customer findByemail(String email) {
	
		return userRepository.findBycustEmail(email); 
	}
	public GymOwner findByemailowner(String email) {
		
		return ownerRepository.findByownerEmail(email); 
	}
	
}
