package Gym.Mngmt.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.modal.GymDetails;
import Gym.Mngmt.modal.GymOwner;
import Gym.Mngmt.repository.GymDetailsRepository;
import Gym.Mngmt.repository.OwnerRepository;
import Gym.Mngmt.repository.UserRepository;




@Service
public class GymdetailsServiceimpl implements GymDetailsService {

	@Autowired
	GymDetailsRepository gymRepository;
	@Autowired
	private OwnerRepository ownerRepository;
	@Autowired
	private UserRepository userRepository;

	
	@Override
	public GymDetails addGymDetails(GymDetails gymDetails) {
		this.gymRepository.save(gymDetails);
		return gymDetails;
	}
	
	@Override
	public List<GymDetails> getGymdetails() {
		
		return this.gymRepository.findAll() ;
	}

	@Override
	public void saveGymdetails(GymDetails gymdetails) {
		this.gymRepository.save(gymdetails);
		
	}

	@Override
	public GymDetails getGymdetailsById(long id) {
		
		return (GymDetails) this.gymRepository.getById(id);
	}

	@Override
	public void deleteGymdetailsById(Integer id) {
	
		
	}
	
	

	@Override
	public List<GymDetails> getGymDataById(long gymId) {
		List<GymDetails> gymdetails = new ArrayList<GymDetails>();
		 gymdetails= this.getGymDataById(gymId);
		return gymdetails;
	}

	@Override
	public List<GymOwner> getGymOwners() {
		return (List<GymOwner>) this.ownerRepository.findAll();

	}

	@Override
	public List<Customer> getCustomers() {
		return (List<Customer>) this.userRepository.findAll();

	}

	
	
	

}
