package Gym.Mngmt.Controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.repository.GymDetailsRepository;
import Gym.Mngmt.repository.UserRepository;

@Controller
@RequestMapping("/cust")
public class CustomerController {
	
	@Autowired
	UserRepository userrepository;
	
	@Autowired
	GymDetailsRepository gymdetailsRepository;
	@Autowired
	private Gym.Mngmt.services.GymDetailsService gymDetailsService;
	
	@RequestMapping("/home")
	public String viewHomePage() {
		return "customer/customerhome";
	}
	
	@GetMapping("/updatecustomer")
	public String updateCustomerpage(Model model,Principal principal) {
		String email=principal.getName();
		model.addAttribute("customer", this.userrepository.findBycustEmail(email));
		return "customer/updatecustomer";
	}
	
	@PostMapping("/updatecustomer")
	public String updateCustomer(@Valid @ModelAttribute("customer") Customer customer,BindingResult result) {
		if(result.hasErrors())
		{
			System.out.println("result");
			return "customer/updatecustomer";
		}
		this.userrepository.save(customer);
		return "customer/updatecustomer";
	}
	
	@GetMapping("/index/{city}")
	public String indexPage(@PathVariable("city") String city2, Model model ) {
		/*
		 * String city[] =
		 * {"Mumbai","Delhi","Pune","Chennai","Bangalore","Kolkata","Gurgaon","Gujrat",
		 * "Haryana","Bhopal"}; String city1 = "Sangli";
		 * 
		 * 
		 * System.out.println(city);
		 */
			//model.addAttribute("listcity", gymDetailsService.getGymdetails());
			List<Gym.Mngmt.modal.GymDetails> gymDetails = this.gymdetailsRepository.findGymDetailsByUser(city2);
			model.addAttribute("listcity", gymDetails);
		
		
		
		return "customer/citywisegym";
		
	}
	 @GetMapping("/showgym/{gymId}")
	  
	  public String viewHomePage(@PathVariable("gymId") long id,Model model) {
	  
	  
			/*
			 * model.addAttribute("listGymdetails",gymDetailsService.getAllGymdetails() );
			 */
	  
			/*
			 * List<GymDetails> Gymdetail = this.gymDetailsService.getAllGymdetails();
			 */	
		 
	  
	   Gym.Mngmt.modal.GymDetails gymdetail =this.gymDetailsService.getGymdetailsById(id);
	  
	  model.addAttribute("listGymdetails", gymdetail);
	  
	  return "customer/View_Details";
	  }
}
