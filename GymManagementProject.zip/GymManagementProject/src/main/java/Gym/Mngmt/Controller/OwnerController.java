package Gym.Mngmt.Controller;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.view.RedirectView;

import Gym.Mngmt.modal.Address;
import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.modal.GymDetails;
import Gym.Mngmt.modal.GymOwner;
import Gym.Mngmt.repository.FileUploadUtil;
import Gym.Mngmt.repository.GymDetailsRepository;
import Gym.Mngmt.repository.OwnerRepository;
import Gym.Mngmt.repository.UserRepository;
import Gym.Mngmt.services.GymDetailsService;

@Controller
@RequestMapping("/ownercon")
public class OwnerController {

	@Autowired
	private GymDetailsService gymDetailsService;
	
	@Autowired
	private GymDetailsRepository gymRepository;
	
	@Autowired
	OwnerRepository ownerrepo;

	
	  @RequestMapping("/home") public String ownerPage() { return "owner/owner"; }
	 

	@RequestMapping("/addgymdata")
	public String addGymdetails(Model model) {
		GymDetails gymDetails = new GymDetails();
		model.addAttribute("gymDetail", gymDetails);
		return "owner/gymDetails";
	}

//	@PostMapping("/saveGymdata")
//	public String saveExpense(@ModelAttribute GymDetails gymDetails, Model model) {
//		this.gymDetailsService.saveGymdetails(gymDetails);
//		return "redirect:/owner";
//	}

	@PostMapping("/saveGymdata")
	public RedirectView saveGymData(@Valid @ModelAttribute("gymDetail") GymDetails gymDetails, BindingResult result,
			Model model, @ModelAttribute Address address, @RequestParam("image") MultipartFile multipartFile,HttpSession session,Principal principal)
			throws IOException {
		if(result.hasErrors())
		{
			System.out.println("result");
			session.setAttribute("error", "Empty Not Accepted");
			return new RedirectView("addgymdata", true);
		}
		//gymDetails.setAddress(address);
//		String name=principal.getName();
//		GymOwner gymOwner=ownerrepo.findByownerEmail(name);
//		gymOwner.getGymDetails().add(gymDetails);
		session.setAttribute("gymId", gymDetails.getGymId());
		
		String fileName = StringUtils.cleanPath(multipartFile.getOriginalFilename());
		gymDetails.setGymPhoto(fileName);
		
	//	ownerrepo.save(gymOwner);
//		 GymDetails saveddetail= this.userRepository.save(gymDetails);
		GymDetails saveddetail = this.gymDetailsService.addGymDetails(gymDetails);

		String uploadDir = "gymDetails-photos/" + saveddetail.getGymId();

		FileUploadUtil.saveFile(uploadDir, fileName, multipartFile);
		

		return new RedirectView("home", true);
	}

	// for adding gymDetails throgh gym owner
//	@PostMapping("/saveGymdata")
//	public String  saveGymData(@Valid @ModelAttribute("gymDetail") GymDetails gymDetails,BindingResult result, Model model, @ModelAttribute Address address,  @RequestParam("image") MultipartFile file )  throws IOException {
//		
//	//	System.out.println("heloooooooooooooooooooooooooooo");
//		if(result.hasErrors()) {
//			return "gymDetails";
//		}
//		gymDetails.setGymPhoto(file.getOriginalFilename());
////		contact.setImage(file.getOriginalFilename());
////		System.out.println(gymDetails);
////		File saveFile = new ClassPathResource("static/img").getFile();
////		System.out.println(saveFile);
////
////		Path path = Paths.get(saveFile.getAbsolutePath() + File.separator + file.getOriginalFilename());
////
////		Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
//		//Address address = new Address(street , state, city, pincode);
//		gymDetails.setAddress(address);
//		this.gymDetailsService.addGymDetails(gymDetails);
//		return "owner" ;
//	}
	
	@GetMapping("/updateowner")
	public String updateCustomerpage(Model model,Principal principal) {
		String email=principal.getName();
		model.addAttribute("owner", this.ownerrepo.findByownerEmail(email));
		return "owner/updateowner";
	}
	
	@PostMapping("/updateowner")
	public String updateCustomer(@Valid @ModelAttribute("owner") GymOwner owner,BindingResult result) {
		if(result.hasErrors())
		{
			System.out.println("result");
			return "owner/updateowner";
		}
		this.ownerrepo.save(owner);
		return "owner/updateowner";
	}

	@GetMapping("/showGymData")
	public String getGymDetails(Model model, HttpSession session,Principal p) {
		// long gymId=(long)session.getAttribute("gymId");
//		long gymId=2L;
		String email=p.getName();
		
		List<GymDetails> gymdetails = gymRepository.getGymdetailsByOwnerId(ownerrepo.findByownerEmail(email).getOwnerId());
		model.addAttribute("Gymdetaillist", gymdetails);
		return "owner/showGymData";
	}

	// getting gymData
	@GetMapping("/gymdata")
	public String getAllDetails(Model model) {
		List<GymDetails> gymdetailsList = this.gymDetailsService.getGymdetails();
		System.out.println(gymdetailsList);
		model.addAttribute("gymdetails", gymdetailsList);

		return "gymdata";
	}

	// for updating gym data
	@GetMapping("/updateGymData/{gymId}")
	public String updateGymData(@PathVariable(value = "gymId") String id, Model model,
			@ModelAttribute("gymDetails") GymDetails gymDetails, 
			BindingResult result) {

		long id1 = Long.parseLong(id);
		GymDetails gymDetail = this.gymDetailsService.getGymdetailsById(id1);
		model.addAttribute("gymDetail", gymDetail);

		return "owner/updateGym";
	}
	@PostMapping("/updateGymDetails")
	public String UpdatedGymData(@ModelAttribute GymDetails gymDetails,Model model) {
		GymDetails savedUser = gymDetailsService.addGymDetails(gymDetails);
		return "redirect:/ownercon/home";
	}

//	@RequestMapping("/home")
//	public String viewHomePage() {
//		return "owner/ownerhome";
//	}

}
