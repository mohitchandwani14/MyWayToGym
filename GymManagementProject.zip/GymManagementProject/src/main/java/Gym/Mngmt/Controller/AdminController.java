package Gym.Mngmt.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.modal.GymOwner;
import Gym.Mngmt.services.GymDetailsService;

@Controller
@RequestMapping("/admin")
public class AdminController {
	@Autowired
	GymDetailsService gymDetailsService;
	
	@RequestMapping("/home")
	public String viewHomePage() {
		return "admin/adminhome";
	}
	
	@RequestMapping("/showGymOwner")
	public String showgymOwner(Model model) {

		List<GymOwner> gymOwner = this.gymDetailsService.getGymOwners();
		model.addAttribute("gymOwner", gymOwner);
		return "admin/showOwner";
	}

	@RequestMapping("/showCustomer")
	public String showCustomer(Model model) {
		List<Customer> customer = this.gymDetailsService.getCustomers();
		model.addAttribute("customer", customer);
		return "admin/showCustomer";
	}

}
