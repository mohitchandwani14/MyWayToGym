package Gym.Mngmt.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;



import Gym.Mngmt.modal.Address;
import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.modal.GymOwner;
import Gym.Mngmt.modal.Login;
import Gym.Mngmt.modal.User;
import Gym.Mngmt.repository.GymDetailsRepository;
import Gym.Mngmt.services.UserService;

@Controller
public class GymController {
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	@Autowired
	GymDetailsRepository gymdetailsRepository;
	@Autowired
	private Gym.Mngmt.services.GymDetailsService gymDetailsService;
	
	@Autowired
	UserService userService;
	
		@GetMapping("/")
		public String viewHomePage() {
			return "homepage1";
		}
		@GetMapping("/register")
		public String register(Model model) {
			model.addAttribute("customer", new Customer());
			return "Register";
		}
		@GetMapping("/login")
		public String login() {
			return "Login";
		}
		
	
		
//		@RequestMapping("/")
//		public String Welcome(HttpServletRequest request) {
//			request.setAttribute("mode", "MODE_HOME");
//			return "welcomepage";
//		}
//		@RequestMapping("/register")
//		public String registration(HttpServletRequest request) {
//			request.setAttribute("mode", "MODE_REGISTER");
//			return "welcomepage";
//		}
//
		@PostMapping("/save-user")
		public String registerUser(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,Model model,  @RequestParam String custName,@RequestParam String custEmail,@RequestParam String custPassword,@RequestParam String custMobile,@RequestParam String age,@RequestParam(value="custGender",defaultValue="Other") String custGender, HttpServletRequest request,@RequestParam(value="type",defaultValue="ROLE_CUSTOMER") String type) {
			if(result.hasErrors())
			{
				System.out.println("result");
				return "Register";
			}
			
			
			Login login=new Login(custEmail,passwordEncoder.encode(custPassword),type);
			userService.saveMyUser(login);
			
			if(type.equals("ROLE_CUSTOMER")) {
				
				Customer cust=new Customer(custName,custMobile,custEmail,login.getPassword(),custGender,age,customer.getStreet(),customer.getCity(),customer.getState(),customer.getPincode());
				userService.saveMyUser(cust);
			}
			
			else {
				
				GymOwner gym=new GymOwner(custName,custMobile,custEmail,login.getPassword(),custGender,age,customer.getStreet(),customer.getCity(),customer.getState(),customer.getPincode());
				userService.saveMyUser(gym);
			}
				
			request.setAttribute("mode", "MODE_HOME");
			return "homepage1";
		}
//		@PostMapping("/save-user")
//		public String registerUser(@ModelAttribute("customer") Customer customer,BindingResult result1,Model model,@RequestParam String type) {
//			Login login=new Login(customer.getCustEmail(),customer.getCustPassword(),type);
//			userService.saveMyUser(login);
//			
//			if(type.equals("customer")) {
////				Address add=new Address(customer.,state,city,pincode);
//				Customer cust=new Customer(customer.getCustName(),customer.getCustMobile(),customer.getCustEmail(),customer.getCustPassword(),customer.getCustGender(),customer.getCustAge(),customer.getAddress());
//				userService.saveMyUser(cust);
//			}
//			
//			else {
//				//Address add=new Address(street,state,city,pincode);
//				GymOwner gym=new GymOwner(customer.getCustName(),customer.getCustMobile(),customer.getCustEmail(),customer.getCustPassword(),customer.getCustGender(),customer.getCustAge(),customer.getAddress());
//				userService.saveMyUser(gym);
//			}
//				
//			//request.setAttribute("mode", "MODE_HOME");
//			return "Homepage";
//		}
//		
		@GetMapping("/index/{city}")
		public String indexPage(@PathVariable("city") String city2, Model model ) {
			/*
			 * String city[] =
			 * {"Mumbai","Delhi","Pune","Chennai","Bangalore","Kolkata","Gurgaon","Gujrat",
			 * "Haryana","Bhopal"}; String city1 = "Sangli";
			 * 
			 * 
			 * System.out.println(city);
			 */
				//model.addAttribute("listcity", gymDetailsService.getGymdetails());
				List<Gym.Mngmt.modal.GymDetails> gymDetails = this.gymdetailsRepository.findGymDetailsByUser(city2);
				model.addAttribute("listcity", gymDetails);
			
			
			
			return "citywisegym";
			
		}
		 @GetMapping("/showgym/{gymId}")
		  
		  public String viewHomePage(@PathVariable("gymId") long id,Model model) {
		  
		  
				/*
				 * model.addAttribute("listGymdetails",gymDetailsService.getAllGymdetails() );
				 */
		  
				/*
				 * List<GymDetails> Gymdetail = this.gymDetailsService.getAllGymdetails();
				 */	
			 
		  
		   Gym.Mngmt.modal.GymDetails gymdetail =this.gymDetailsService.getGymdetailsById(id);
		  
		  model.addAttribute("listGymdetails", gymdetail);
		  
		  return "View_Details";
		  }
		@RequestMapping("/logout")
		public String logoutcust(HttpSession session,HttpServletResponse respone) {
			session.removeAttribute("customer");
			session.invalidate();
			return "homepage1";
		}
		@GetMapping("/city")
		public String citylist() {
			return "citywisegym";
		}
		/*
		 * @RequestMapping ("/login-user") public String
		 * loginUser(@ModelAttribute("login") Login login, HttpServletRequest
		 * request,Model model,HttpSession session) { Login
		 * l=userService.findByemailAndPassword(login.getEmail(), login.getPassword());
		 * model.addAttribute("login", l); Customer cust=null; if(l!=null) {
		 * System.out.println(l); if(l.getType().equals("customer")) {
		 * cust=userService.findByemail(l.getEmail()); session.setAttribute("customer",
		 * cust); //return "Customer/updatecustomer"; return "customer/customerhome"; }
		 * else if(l.getType().equals("admin")) return "Homepage"; else return
		 * "citylist";
		 * 
		 * 
		 * 
		 * } else { session.setAttribute("error", "Invalid Username or Password");
		 * request.setAttribute("mode", "MODE_LOGIN"); return "login";
		 * 
		 * } }
		 */
}
