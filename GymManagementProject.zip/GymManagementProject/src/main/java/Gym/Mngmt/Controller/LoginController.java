package Gym.Mngmt.Controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import Gym.Mngmt.modal.Customer;
import Gym.Mngmt.modal.GymOwner;
import Gym.Mngmt.services.UserService;

@Controller
@RequestMapping("/login")
public class LoginController {
	@Autowired
	UserService userService;
		
	@RequestMapping("/role")
	public String loginuser(Authentication auth,HttpSession hs) {
		String email = auth.getName();
		String role = auth.getAuthorities().toString();
		System.out.println(email+""+role);
		if(role.equalsIgnoreCase("[ROLE_ADMIN]")) {
			return "redirect:/admin/home";
		}
		else {
			if(role.equalsIgnoreCase("[ROLE_OWNER]")) {
				GymOwner owner=userService.findByemailowner(email);
				System.out.println(owner);
				hs.setAttribute("owner",owner);
				return "redirect:/ownercon/home";
			}else {
				if(role.equalsIgnoreCase("[ROLE_CUSTOMER]")){
					Customer cust=userService.findByemail(email);
					System.out.println(cust);
					hs.setAttribute("customer",cust);
					return "redirect:/cust/home";
				}
			}
			return "login";
		}
	}
}
