package Gym.Mngmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymManagementProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
